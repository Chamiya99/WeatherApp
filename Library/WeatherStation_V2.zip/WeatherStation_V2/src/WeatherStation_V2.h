// WeatherStation_V2.h

#ifndef WeatherStation_V2_h
#define WeatherStation_V2_h

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>
#include <Adafruit_BMP280.h>
#include <Arduino_JSON.h>
#include <Firebase_ESP_Client.h>
#include "addons/TokenHelper.h"
#include "addons/RTDBHelper.h"

class WeatherStation {
public:
    WeatherStation();
    void initialize(const char* apiKey, const char* dbUrl, const char* serverIp, const char* ssid, const char* password, const char* loc);
    void updateData();
    void checkState(const char* stateType);  // Pass stateType as an argument
    void blinkLED();
    void connectToWiFi();
    
private:
    DHT dht11;
    Adafruit_BMP280 bmp;

    int temperature;
    int humidity;
    int pressure;
    bool sensorOn;
    unsigned long sendDataPrevMillis;
    bool signupOK;

    // Add these lines in the private section of WeatherStation_V2.h
    const char* API_KEY = "your_api_key";
    const char* DATABASE_URL = "your_database_url";
    const char* SERVER_IP = "your_server_ip";
    const char* WIFI_SSID = "your_wifi_ssid";
    const char* WIFI_PASSWORD = "your_wifi_password";
    const char* location = "your_default_location";


    FirebaseData fbdo;
    FirebaseAuth auth;
    FirebaseConfig config;

    void loadBMP280Data();
    void loadDHT11Data();
};

#endif
