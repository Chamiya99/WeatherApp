// WeatherStation_V2.cpp

#include "WeatherStation_V2.h"
#define DHTPIN 19
#define DHTTYPE DHT11
#define LED_GRN_PIN 12
#define LED_RED_PIN 13
#define LED_BLUE_PIN 14

WeatherStation::WeatherStation(const char* apiKey, const char* dbUrl, const char* serverIp, const char* ssid, const char* password, const char* loc) : dht11(DHTPIN, DHTTYPE), API_KEY(apiKey), DATABASE_URL(dbUrl), SERVER_IP(serverIp), WIFI_SSID(ssid), WIFI_PASSWORD(password), location(loc) {
    // Constructor, if needed
}


void WeatherStation::initialize(const char* apiKey, const char* dbUrl, const char* serverIp, const char* ssid, const char* password, const char* loc){
    API_KEY = apiKey;
    DATABASE_URL = dbUrl;
    SERVER_IP = serverIp;
    WIFI_SSID = ssid;
    WIFI_PASSWORD = password;
    location = loc;

    pinMode(LED_GRN_PIN, OUTPUT);
    pinMode(LED_RED_PIN, OUTPUT);
    pinMode(LED_BLUE_PIN, OUTPUT);

    dht11.begin();
    bmp.begin(0x76);

    Serial.begin(115200);
    connectToWiFi();

    config.api_key = API_KEY;
    config.database_url = DATABASE_URL;

    if (Firebase.signUp(&config, &auth, "", "")) {
        Serial.println("Firebase Signup ok");
        signupOK = true;
    } else {
        Serial.printf("%s\n", config.signer.signupError.message.c_str());
    }

    config.token_status_callback = tokenStatusCallback;
    Firebase.begin(&config, &auth);
    Firebase.reconnectWiFi(true);
}



void WeatherStation::updateData() {
    Serial.println("Start --------------------------------------------------------------");
  checkState("OnOff");
  checkState("Configuration");

  if (sensorOn) {
    digitalWrite(LED_GRN_PIN, HIGH);
    digitalWrite(LED_RED_PIN, LOW);

    if (WiFi.status() != WL_CONNECTED) {
      connectWiFi();
    }

    LoadDHT11Data();
    LoadBMP280Data();
    blinkLED();

    String postData = "temperature=" + String(temperature) +
                      "&humidity=" + String(humidity) +
                      "&pressure=" + String(pressure);

    HTTPClient http;
    http.begin(URL);
    http.addHeader("Content-Type", "application/x-www-form-urlencoded");

    int httpCode = http.POST(postData);
    String payload = http.getString();

    Serial.print("URL :");
    Serial.println(URL);
    Serial.print("Data:");
    Serial.println(postData);
    Serial.print("httpCode :");
    Serial.println(httpCode);
    Serial.print("payload :");
    Serial.println(payload);
    Serial.println("----------------------------------");

    float fbTemperature = dht11.readTemperature();
    float fbHumidity = dht11.readHumidity();
    float fbPressure = bmp.readPressure() / 100;

    if (Firebase.ready() && signupOK && (millis() - sendDataPrevMillis > 5000 || sendDataPrevMillis == 0)) {
      blinkLED();
      sendDataPrevMillis = millis();

      if (Firebase.RTDB.setInt(&fbdo, "DHT_11/Temperature", fbTemperature) &&
          Firebase.RTDB.setFloat(&fbdo, "DHT_11/Humidity", fbHumidity) &&
          Firebase.RTDB.setFloat(&fbdo, "DHT_11/Pressure", fbPressure) &&
          Firebase.RTDB.setString(&fbdo, "DHT_11/location", location)) {
        Serial.println("Firebase Data Sent Successfully");
      } else {
        Serial.println("Failed to Send Data to Firebase");
        Serial.println("REASON: " + fbdo.errorReason());
      }
    }
    Serial.println("End -----------------------------------------------------------------");
  } else {
    digitalWrite(LED_RED_PIN, HIGH);
    digitalWrite(LED_GRN_PIN, LOW);
  }
}

void WeatherStation::checkState(const char* stateType) {
  String postData = "";
  String payload = "";
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    int httpCode;
    postData = "id=1";
    payload = "";

    Serial.println();
    Serial.println("---------------getdata.php");
    if (stateType == "OnOff") {
      http.begin("http://" + String(SERVER_IP) + "/dht11_project/onoffstate.php");
    }
    if (stateType == "Configuration") {
      http.begin("http://" + String(SERVER_IP) + "/dht11_project/configstate.php");
    }
    http.addHeader("Content-Type", "application/x-www-form-urlencoded");

    httpCode = http.POST(postData);
    payload = http.getString();

    Serial.print("httpCode : ");
    Serial.println(httpCode);
    Serial.print("payload  : ");
    Serial.println(payload);

    http.end();
    Serial.println("---------------");

    JSONVar myObject = JSON.parse(payload);

    if (JSON.typeof(myObject) == "undefined") {
      Serial.println("Parsing input failed!");
      Serial.println("---------------");
      return;
    }

    if (stateType == "OnOff") {
      if (myObject.hasOwnProperty("State")) {
        Serial.print("Sensor State = ");
        Serial.println(myObject["State"]);
      }

      if (strcmp(myObject["State"], "1") == 0) {
        sensorOn = true;
        Serial.println("Sensor ON");
      }
      if (strcmp(myObject["State"], "0") == 0) {
        sensorOn = false;
        Serial.println("Sensor OFF");
      }
    }

    if (stateType == "Configuration") {
      if (myObject.hasOwnProperty("Location")) {
        Serial.print("Location State = ");
        Serial.println(myObject["Location"]);
        location = String(static_cast<const char*>(myObject["Location"]));
      }
    }
  }
  delay(1000);
}

void WeatherStation::blinkLED() {
  digitalWrite(LED_BLUE_PIN, HIGH);
  delay(1000);
  digitalWrite(LED_BLUE_PIN, LOW);
  delay(1000);
}

void WeatherStation::connectToWiFi() {
    WiFi.mode(WIFI_OFF);
    delay(1000);
    WiFi.mode(WIFI_STA);

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    Serial.println("Connecting to WiFi");

    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }

    Serial.print("Connected to: ");
    Serial.println(WIFI_SSID);
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());
}

void WeatherStation::loadBMP280Data() {
    pressure = bmp.readPressure() / 100;

    if (isnan(pressure)) {
        Serial.println("Failed to read data from BMP280 sensor!");
        pressure = 0;
    }

    Serial.printf("Pressure: %d hPa\n", pressure);
}

void WeatherStation::loadDHT11Data() {
    temperature = dht11.readTemperature();
    humidity = dht11.readHumidity();

    if (isnan(temperature) || isnan(humidity)) {
        Serial.println("Failed to read data from DHT11 sensor!");
        temperature = 0;
        humidity = 0;
    }

    Serial.printf("Temperature: %d °C\n", temperature);
    Serial.printf("Humidity: %d %%\n", humidity);
}
